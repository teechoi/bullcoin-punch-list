# Bullcoin — asset handoff

Everything here is production-ready and correctly named. Read this file before
using anything: **several filenames currently on the site do not match their
contents**, and fixing that is part of the job.

Companion punch list (17 findings, with a hero mockup showing the target):
<https://teechoi.github.io/bullcoin-punch-list/>

- Reviewed: 7 Sep 2026, branch `feat-brand-lore`, desktop Chrome at 1728x630.
- Everything in this zip is licensed/owned by the project. Nothing here is AI
  slop pulled off the internet; the stills come from the shared Bull Assets
  drive and the motion from `~/Documents/bull`.

---

## 1. If you only do three things

1. **Point the buy button at a swap.** Both "Buy $BULL" buttons currently
   scroll to the how-to text. There is no buy path on the page. (`B01`)
2. **Add the share image.** `04-share-card/og-image-1200x630.jpg` is rendered
   and ready. Right now every X and Telegram link renders a blank card. (`B02`)
3. **Replace the hero.** Drop the low-poly 3D GIF and use
   `02-hero-motion/mark-loop.mp4`. (`B04`)

---

## 2. Folder map

```
01-brand/               the character and the X header
02-hero-motion/         6 loops as mp4 + webm + poster jpg  <- USE THESE
03-community-stills/    15 stills as webp + jpg, 1400 px     <- USE THESE
04-share-card/          og:image, 1200x630, rendered
source/stills-2048/     the 2048 px originals (re-crop from here)
source/motion-gif-originals/  the untouched GIF masters
fonts/                  Shrikhand + Baloo 2, the site's two faces
manifest.json           machine-readable index of everything above
```

Use `02`, `03` and `04` on the site. `source/` is only for re-rendering.

---

## 3. Hero motion — use video, not GIF

The site's hero is a low-poly 3D GIF that is not the canonical character. The
canonical character is the flat 2D model in `01-brand/`. Six finished loops of
it are in `02-hero-motion/`, already encoded for web.

| loop           | mp4    | webm   | gif original | what it is                                                                                             |
|----------------|--------|--------|--------------|--------------------------------------------------------------------------------------------------------|
| mark-loop      | 271 KB | 320 KB | 3.3 MB       | The logo mark itself, orbiting leaves. Near-black ground. USE THIS FIRST.                              |
| bull-army      | 585 KB | 763 KB | 2.0 MB       | Lime ground, full herd inside a charcoal roundel.                                                      |
| mark-motion    | 604 KB | 559 KB | 2.6 MB       | The mark again, black and lime. Cropped square from a 360x640 portrait master.                         |
| body-loop      | 305 KB | 263 KB | 2.9 MB       | Walk cycle across lime and cream.                                                                      |
| editorial-cuts | 693 KB | 435 KB | 1.1 MB       | Four-up editorial cuts, palette shifts between panels.                                                 |
| logo-reveal    | 242 KB | 199 KB | 0.4 MB       | Mark draws on, then the character lands. Cream ground. Starts on an empty card, so never put it first. |

**Order matters.** Grounds alternate dark / lime / dark / cream so the lime page
background never fights the frame. Keep that order. `logo-reveal` opens on an
empty card, so it must never be the first frame a visitor sees.

```html
<video
  class="hero-art"
  autoplay muted loop playsinline
  preload="metadata"
  poster="/motion/mark-loop-poster.jpg"
  width="540" height="540">
  <source src="/motion/mark-loop.webm" type="video/webm">
  <source src="/motion/mark-loop.mp4"  type="video/mp4">
</video>
```

`muted` and `playsinline` are both required or iOS will refuse to autoplay.
Always ship the poster: without it the hero is blank until the video decodes,
and the poster is what a page snapshot captures.

**Do not swap in the MP4s that already sit next to the GIFs in
`~/Documents/bull`.** Those are masters at inconsistent bitrates — seven are
smaller than their GIF, five are *bigger* (`logo-reveal`'s master is 3x its
GIF). The encodes in `02-hero-motion/` are the web ones: 12.6 MB of GIF became
2.64 MB of H.264 at a higher resolution and framerate than the GIFs.

### Palette rule for any future loop

There are 19 loops in the archive; only these six are safe in the lime hero.
A loop can only go in a lime frame if its ground is **lime, cream, olive or
near-black**. Measured and rejected:

- `bull-two-step` — 42% navy `#000048` with a magenta ring
- `02-spotlight` — navy
- `01-roller-rink`, `03-rooftop-boombox` — purple
- `new-buy-forward`, `new-buy-cash-walk`, `new-buy-true-walk` — warm orange
- `03-forward-charge` — brown

Those are all fine on X, or on one of the site's black sections. Not in the hero.

---

## 4. Community stills

15 stills at 1400 px as WebP with a JPEG fallback. Groups are a suggestion for
placement, not a strict taxonomy.

| file                | group     | webp   | source    | what it is / where it is used now                                                                                    |
|---------------------|-----------|--------|-----------|----------------------------------------------------------------------------------------------------------------------|
| welcome-to-the-herd | community | 144 KB | 2048x2048 | Stampede with WELCOME TO THE HERD lettering. The one asset already named correctly on the site.                      |
| alley-bats          | community | 248 KB | 2048x2048 | Night alley, bats defeated. Currently on the site as drive-hoodify.webp.                                             |
| hoodify-selfie      | community | 222 KB | 2048x2048 | Bull and the Robinhood house mascot. Currently on the site as drive-monument.webp. Clear with Tyler before shipping. |
| cash-bath           | meme      | 64 KB  | 2048x2048 | Bathtub of cash, cigar. Currently on the site as drive-bats.webp.                                                    |
| escalator           | meme      | 58 KB  | 2048x2048 | Subway escalator, green glow. Currently on the site as drive-bath.webp.                                              |
| bull-run-stadium    | action    | 120 KB | 2048x2048 | Stadium sprint, BULL RUN scoreboard. Currently on the site as drive-escalator.webp.                                  |
| gbull-coffee        | meme      | 70 KB  | 2048x2048 | Reclining in a gBull coffee cup. Currently on the site as drive-run.webp.                                            |
| monument-build      | community | 597 KB | 2048x2048 | Herd building a stone Bull monument. Best fit for 'grow the chain with the herd'.                                    |
| leap-cube           | action    | 98 KB  | 2048x2048 | Vaulting off a lime cube with the leaf logo. Brand-forward, lots of lime.                                            |
| chart-climb         | action    | 58 KB  | 896x1200  | Riding a rising green candlestick chart. Natural above Bullnomics.                                                   |
| stay-bullish-poster | community | 119 KB | 896x1200  | STAY BULLISH poster with a herd behind. Works as a section header behind type.                                       |
| new-buy-comic       | meme      | 117 KB | 2048x2048 | NEW BUY comic panel, falling cash.                                                                                   |
| goated              | meme      | 116 KB | 2048x1766 | Two-panel: HIM? OH, HE'S GOATED. Reads at thumbnail size.                                                            |
| brokie              | meme      | 72 KB  | 2048x2048 | Wojak brokie panel. Sharpest of the set for X.                                                                       |
| shared-meal         | community | 100 KB | 2048x2048 | Sharing a meal with another character. Quieter counterweight.                                                        |

```html
<picture>
  <source srcset="/stills/welcome-to-the-herd.webp" type="image/webp">
  <img src="/stills/welcome-to-the-herd.jpg"
       width="1400" height="1400"
       alt="The Bull riding at the front of a stampeding herd under the words WELCOME TO THE HERD">
</picture>
```

### The filenames on the site are wrong — fix this

The asset names are rotated off their contents. The site's alt text was written
from the filenames, so it currently describes pictures that are not there. This
is wrong at the source too (`bull-canon.vercel.app` has the same rotation), so
fix it in both places.

| current filename on site | actually contains   | status          |
|--------------------------|---------------------|-----------------|
| drive-herd.webp          | welcome-to-the-herd | correct already |
| drive-hoodify.webp       | alley-bats          | wrong           |
| drive-monument.webp      | hoodify-selfie      | wrong           |
| drive-bats.webp          | cash-bath           | wrong           |
| drive-bath.webp          | escalator           | wrong           |
| drive-escalator.webp     | bull-run-stadium    | wrong           |
| drive-run.webp           | gbull-coffee        | wrong           |

Only `drive-herd` is right. Every other alt string on that carousel describes
the wrong image and needs rewriting once the files are renamed. Use the
"what it is" column in the table above as the basis for each new alt.

### Carousel bugs to fix while you are in there

- **Six of nineteen images never load.** They carry `loading="lazy"` inside a
  horizontally-offset track, so the browser never considers them in-viewport.
  The files return `200`. Eager-load the first three and preload the rest on
  mount instead of relying on viewport detection. (`B03`)
- **The track eats the scroll wheel.** With the cursor over the carousel the
  page barely scrolls. Only capture horizontal `deltaX`; let `deltaY` through. (`M07`)
- **Arrows are 38x38** (44 minimum), sit on top of the third card, and the
  disabled state is a dark filled circle that reads as broken. (`M09`)
- **The third card is sliced mid-image** at the container edge with no fade or
  peek treatment. (`M10`)

---

## 5. Share card

`04-share-card/og-image-1200x630.jpg` — lime ground, dot grid, Shrikhand
wordmark, the cut-out character standing on the bottom edge. Rendered at the
exact aspect X and Telegram want.

```html
<meta property="og:title"       content="Bullcoin — Bullin' on Robinhood">
<meta property="og:description" content="$BULL. The bullest breed on Robinhood Chain. 100% bullshit, 0% cap.">
<meta property="og:type"        content="website">
<meta property="og:url"         content="https://YOUR-DOMAIN/">
<meta property="og:image"       content="https://YOUR-DOMAIN/og-image-1200x630.jpg">
<meta property="og:image:width"  content="1200">
<meta property="og:image:height" content="630">
<meta name="twitter:card"  content="summary_large_image">
<meta name="twitter:image" content="https://YOUR-DOMAIN/og-image-1200x630.jpg">
<link rel="canonical" href="https://YOUR-DOMAIN/">
```

`og:image` must be an absolute URL. The card is currently declared
`summary_large_image` with no image at all, which is why X reserves a large
image slot and renders nothing. Test the real URL through X's card validator
and by pasting it into a Telegram chat before you call it done.

---

## 6. Icons

The only icon the site declares is `/bullcoin/logo.webp`. WebP favicons are not
reliable, and there is no apple-touch-icon or manifest, so saving the site to a
phone home screen gives a blank tile. Generate from `01-brand/bull-model-cutout.png`
or the head-only mark:

- `favicon.ico` (32 px), `icon-192.png`, `icon-512.png`, `apple-touch-icon.png` (180 px)
- a small `manifest.webmanifest` referencing the two PNGs

---

## 7. Other fixes not related to these files

Full detail and evidence for each is on the punch list page.

- `M06` The Bullnomics tiles render **`0` total supply, `0 / 0` tax and `0% LP
  burned`** until a scroll animation fires — which is also what you get with JS
  off or reduced motion on. Put the real values in the HTML and animate from
  them, not toward them.
- `M08` Every nav link and both hero CTAs are `href="/"`, with the scrolling
  bolted on in JS. Cmd-click and open-in-new-tab all land on the homepage top.
  Use the real fragment (`href="#the-lore"`) and `preventDefault` on top.
- `M11` "The Bull Mark" has a half-empty left column and a stray vertical rule
  from an empty grid cell in the USPTO card header.
- `P18` 30 elements carry `.reveal`. The `prefers-reduced-motion` block is real
  but only covers the hero entrance and the carousel hint — it never mentions
  `.reveal`, so with reduced motion on everything below the hero still waits to
  fade in. Add `.reveal` to that block.
- `P19` No canonical and no robots meta. Set canonical on production.
- Copy: cut "Not Bitcoin, Bullcoin. It's better." (`P13`) and reword
  "check it for yourself bulltard" on the USPTO link (`P14`).

### Already correct — do not redo

Heading order, `lang`, viewport meta, meta description, `rel="noopener
noreferrer"` on externals, aria-labels on the contract pill / arrows / burger,
no horizontal page overflow, all four Bullish Links resolve, the Save button is
pinned visible under `(hover: none)`, the contract-copy toast works, and the
hero entrance has a proper reduced-motion branch. The Shrikhand + Baloo 2
pairing stays as-is.

---

## 8. Do not ship

Four images in the shared Bull Assets drive are deliberately **not** in this
zip: one uses a recognisable public figure's likeness, one places the character
inside another studio's cartoon, and two are disaster scenes (a burning
aircraft, a body on a floor). If you find them, they are not cleared.

`hoodify-selfie` **is** included but places our character next to Robinhood's
own house mascot. Confirm with Tyler before it goes on the production domain.

---

## 9. Known gap in the review

The 17 findings were all checked at 1728x630 in desktop Chrome. Mobile was never
rendered, so **treat every finding as desktop-only**. The responsive work exists
— breakpoints at 1020 / 880 / 640 / 600 / 560, a `.burger`, a
`.carousel-mobile-dock`, `(hover: none)` rules — but none of it is verified.
Since most traffic arrives from a Telegram or X link on a phone, that viewport
deserves its own pass: the burger open/close, the hero at 390 px, the 12-row
USPTO table stacking, the four-across How To Bull cards, and tap targets.

Keyboard tab order, focus rings, Safari, Firefox and in-app browsers are also
unchecked.
